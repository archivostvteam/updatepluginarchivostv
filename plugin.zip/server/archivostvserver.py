# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/archivostv/archivostvserver.py
# coding: utf-8

import scrapertools
import httptools